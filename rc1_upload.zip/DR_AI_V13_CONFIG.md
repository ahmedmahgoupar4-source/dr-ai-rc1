# Dr. AI V13.1 — Preflight

## قبل تثبيت APK
المطلوب فقط عند توفر الكمبيوتر:
1. Android Studio
2. Android SDK
3. جهاز Android أو USB debugging

## Token server
شغّل `server/server.js` على الكمبيوتر مع:
`OPENAI_API_KEY=...`

ثم ضع عنوان الخادم في التطبيق، مثال:
`http://192.168.1.10:8787`

لا تضع مفتاح OpenAI داخل التطبيق.

## الاختبار
- افتح `preflight.html` في متصفح يدعم WebRTC.
- وافق على الميكروفون.
- يجب أن تظهر اختبارات PASS.
- بعد ذلك نبني APK ونختبر Realtime.
