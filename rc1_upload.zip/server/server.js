import express from "express";
import cors from "cors";
import { WebSocketServer } from "ws";
import { enrollFromPcm16, verifyPcm16, resetGate, modelInfo } from "./voice_gate.js";
import { DR_AI_FIXED_VOICE, fixedVoiceConfig } from "./voice_runtime_policy.js";


const CONTROL_WINDOW_MS = Number(process.env.DR_AI_CONTROL_WINDOW_MS || "2600");
const ADDRESS_CONFIDENCE_FLOOR = Number(process.env.DR_AI_ADDRESS_CONFIDENCE_FLOOR || "0.70");
const CONTROL_COOLDOWN_MS = Number(process.env.DR_AI_CONTROL_COOLDOWN_MS || "1400");
const ADDRESS_CONTEXT_MS = Number(process.env.DR_AI_ADDRESS_CONTEXT_MS || "5000");
let lastControlAt = 0;

function pcm16ToWav(pcm, sampleRate=16000, channels=1){
  const header=Buffer.alloc(44);
  header.write("RIFF",0); header.writeUInt32LE(36+pcm.length,4); header.write("WAVE",8);
  header.write("fmt ",12); header.writeUInt32LE(16,16); header.writeUInt16LE(1,20);
  header.writeUInt16LE(channels,22); header.writeUInt32LE(sampleRate,24);
  header.writeUInt32LE(sampleRate*channels*2,28); header.writeUInt16LE(channels*2,32);
  header.writeUInt16LE(16,34); header.write("data",36); header.writeUInt32LE(pcm.length,40);
  return Buffer.concat([header,pcm]);
}

function parseDirectorCommand(text){
  const t=(text||"").trim().toLowerCase().replace(/[.,!?؟،؛:]/g," ").replace(/\s+/g," ");
  if(!t) return null;
  if(/^(اسكت|اسكت بس|اسكت خالص|ما تتكلمش|ماتتكلمش|ما تجاوبش|ماتجاوبش|دكتور اسكت|يا دكتور اسكت|silent|mute)$/.test(t)) return {command:"SILENT"};
  if(/^(جاوب|رد|اتكلم|اتفضل جاوب|اتفضل رد|دكتور جاوب|يا دكتور جاوب|دكتور رد|يا دكتور رد|talk)$/.test(t)) return {command:"TALK"};
  if(/^(اسمع|خليك ساكت واسمع|دكتور اسمع|يا دكتور اسمع|listen)$/.test(t)) return {command:"LISTEN"};
  if(/^(خليه يسأل|خليه يسال|سيبه يسأل|سيبه يسال|دكتور خليه يسأل|يا دكتور خليه يسأل)$/.test(t)) return {command:"LISTEN"};
  if(/^(رد عليه بسخرية|جاوبه بسخرية|جاوب بسخرية)$/.test(t)) return {command:"TALK",style:"teasing"};
  return null;
}


function classifyAddress(text){
  const raw=text||"";
  const t=raw.trim().toLowerCase().replace(/[ًٌٍَُِّْـ]/g,'').replace(/[أإآ]/g,'ا').replace(/[.,!?؟،؛:]/g,' ').replace(/\s+/g,' ');
  if(!t) return {state:"NONE",target:"NONE",confidence:0,reason:"empty"};
  // Ahmed is also a doctor. Generic "doctor" is deliberately ambiguous.
  if(/\b(دكتور\s*(ai|اي|ايه\s*ايه)|دكتور\s+الذكاء\s+الاصطناعي|يا\s+دكتور\s*(ai|اي|ايه))\b/.test(t)) return {state:"DIRECT",target:"AI",confidence:.99,reason:"explicit Dr AI address"};
  if(/\b(دكتور\s+احمد|يا\s+احمد|يا\s+دكتور\s+احمد)\b/.test(t)) return {state:"HOST_DIRECT",target:"HOST",confidence:.99,reason:"explicit host doctor address"};
  if(/^يا\s+دكتور\s*$/.test(t)||/^دكتور\s*$/.test(t)||t.includes('يا دكتور')) return {state:"AMBIGUOUS",target:"UNKNOWN",confidence:.50,reason:"doctor address ambiguous: host is also a doctor"};
  if(/\b(?:قولنا|قولي|احكيلنا|جاوبنا|رد علينا)\b/.test(t)) return {state:"LIKELY",target:"AI",confidence:.82,reason:"generic imperative"};
  if(/\b(?:انت|انتا)\b/.test(t)&&/[?؟]/.test(raw)) return {state:"LIKELY",target:"UNKNOWN",confidence:.55,reason:"second-person question target unknown"};
  return {state:"NONE",target:"NONE",confidence:.10,reason:"not clearly addressed"};
}

function conversationState(previous, speaker, address, transcript){
  const now=Date.now();
  const sameSpeaker=previous && previous.speaker===speaker;
  const gap=previous ? now-previous.at : Infinity;
  if(speaker==='HOST') return {state:'HOST_CONTROL',target:'HOST',speak:false,reason:'host is director'};
  if(address.target==='HOST'||address.state==='HOST_DIRECT') return {state:'HOST_TURN',target:'HOST',speak:false,reason:'guest addressed human doctor'};
  if(address.target==='COHOST') return {state:'COHOST_TURN',target:'COHOST',speak:false,reason:'guest addressed Dr Hoor'};
  if(address.state==='AMBIGUOUS'){
    // A generic “doctor” is still ambiguous for guests. For Dr Hoor, it is a
    // likely call to the AI guest unless she explicitly names Ahmed.
    if(speaker==='COHOST_HOOR') return {state:'AI_TURN',target:'AI',speak:true,reason:'co-host generic doctor call'};
    if(previous && previous.target==='AI' && sameSpeaker && gap<=ADDRESS_CONTEXT_MS) return {state:'AI_TURN',target:'AI',speak:true,reason:'continuation of recent Dr AI turn'};
    return {state:'AMBIGUOUS',target:'UNKNOWN',speak:false,reason:'generic doctor address remains ambiguous'};
  }
  if(address.target==='AI' && ['DIRECT','LIKELY'].includes(address.state)) return {state:'AI_TURN',target:'AI',speak:true,reason:'guest addressed Dr AI'};
  return {state:'PUBLIC',target:'NONE',speak:false,reason:'not addressed to Dr AI'};
}

async function transcribeDirectorAudio(pcm,sampleRate){
  if(!process.env.OPENAI_API_KEY || !pcm?.length) return null;
  const wav=pcm16ToWav(pcm,sampleRate);
  const form=new FormData();
  form.append("file",new Blob([wav],{type:"audio/wav"}),"director.wav");
  form.append("model",process.env.DR_AI_COMMAND_TRANSCRIBE_MODEL || "gpt-4o-mini-transcribe");
  form.append("language","ar");
  const r=await fetch("https://api.openai.com/v1/audio/transcriptions",{
    method:"POST",headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},body:form
  });
  if(!r.ok) throw new Error(`transcription ${r.status}`);
  const d=await r.json();
  return d.text||"";
}

const app=express();
app.use(cors());
app.use(express.json({limit:"2mb"}));

app.get("/voice-gate/status",(req,res)=>res.json({...modelInfo(),voice:fixedVoiceConfig()}));

app.post("/voice-gate/reset",(req,res)=>{resetGate();res.json({ok:true});});

app.post("/voice-gate/enroll",async(req,res)=>{
  try{
    const chunks=(req.body?.chunks||[]).map(x=>Buffer.from(x,"base64"));
    const rate=Number(req.body?.sampleRate||16000);
    if(!chunks.length) return res.status(400).json({error:"No PCM enrollment chunks"});
    const result=await enrollFromPcm16(chunks,rate);
    res.json({ok:true,...result});
  }catch(e){res.status(500).json({error:e.message});}
});

app.get("/token", async (req,res)=>{
  if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is missing"});
  const r=await fetch("https://api.openai.com/v1/realtime/client_secrets",{
    method:"POST",
    headers:{
      "Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type":"application/json"
    },
    body:JSON.stringify({
      session:{
        type:"realtime",
        model:"gpt-realtime-2.1",
        audio:{output:{voice:DR_AI_FIXED_VOICE},input:{turn_detection:{type:"server_vad"}}},
        instructions:`You are Dr. AI. Speak natural Egyptian Arabic. Be witty, playful, teasing, warm and concise. Ask one question at most. Yield when interrupted. Never expose private director control data. Persona is locked. The human host is also a doctor. Never assume generic 'doctor' from a guest addresses you; it is ambiguous because Ahmed and Hoor are also doctors. A continuation within the active Dr AI turn may inherit the current target. Hoor may explicitly call you by name or, when clearly addressing the AI guest, use generic 'doctor'. If directly asked whether you are AI, answer truthfully.`
      }
    })
  });
  const data=await r.json();
  res.status(r.status).json(data);
});

const server=app.listen(8787,()=>console.log("Dr. AI token + voice gate server on :8787"));
const wss=new WebSocketServer({server,path:"/voice-gate"});

wss.on("connection",(ws)=>{
  resetGate();
  let queue=[];
  let processing=false;
  let sampleRate=16000;
  let directorAuthorized=false;
  let controlBuffer=[];
  let controlBytes=0;
  let lastGateState="UNKNOWN";
  let lastSpeakerId="UNKNOWN";
  let commandProcessing=false;

  const send=(x)=>{try{ws.send(JSON.stringify(x))}catch{}};

  async function process(){
    if(processing||queue.length===0||ws.readyState!==1) return;
    processing=true;
    const pcm=Buffer.concat(queue.splice(0));
    try{
      const decision=await verifyPcm16(pcm,sampleRate);
      lastGateState=decision.state;
      lastSpeakerId=decision.speakerId||"UNKNOWN";
      if(decision.state==="MATCH" && decision.speakerId==="HOST") directorAuthorized=true;
      else if(decision.speakerId && decision.speakerId!=="HOST") directorAuthorized=false;
      send({type:"gate",...decision,diarization:true});

      if(directorAuthorized && decision.state==="MATCH" && decision.speakerId==="HOST"){
        controlBuffer.push(pcm); controlBytes+=pcm.length;
        const targetBytes=Math.max(32000, Math.floor(sampleRate*2*CONTROL_WINDOW_MS/1000));
        const now=Date.now();
        if(controlBytes>=targetBytes && !commandProcessing && (now-lastControlAt)>=CONTROL_COOLDOWN_MS){
          const cmdPcm=Buffer.concat(controlBuffer.splice(0)); controlBytes=0; commandProcessing=true; lastControlAt=now;
          try{
            const text=await transcribeDirectorAudio(cmdPcm,sampleRate);
            const command=parseDirectorCommand(text);
            if(command) send({type:"control",...command,transcript:text,private:true});
          }catch(e){ send({type:"control_error",private:true,reason:e.message}); }
          finally{ commandProcessing=false; }
        }
      } else { controlBuffer=[]; controlBytes=0; if(decision.state!=="MATCH") directorAuthorized=false; }
    }catch(e){ send({type:"gate",state:"UNKNOWN",score:null,reason:e.message}); }
    processing=false;
    if(queue.length) process();
  }

  ws.on("message",(data,isBinary)=>{
    if(isBinary){ queue.push(Buffer.from(data)); if(queue.reduce((n,b)=>n+b.length,0)>=16000*2*1.6) process(); }
    else{
      try{
        const m=JSON.parse(data.toString());
        if(m.type==="config") sampleRate=Number(m.sampleRate||16000);
        if(m.type==="reset") resetGate();
      }catch{}
    }
  });
});
