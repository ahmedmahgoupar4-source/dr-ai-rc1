// Dr. AI RC-1 fixed voice policy.
// Keep one explicit output voice for the entire runtime. No role/name/dialect
// may change this value. A provider-specific voice can be supplied via env.
export const DR_AI_FIXED_VOICE = process.env.DR_AI_FIXED_VOICE || 'cedar';
export const DR_AI_VOICE_FALLBACK_ENABLED = false;

export function fixedVoiceConfig(){
  return {
    voice: DR_AI_FIXED_VOICE,
    fallbackEnabled: DR_AI_VOICE_FALLBACK_ENABLED,
    profile: 'DR_AI_FIXED_VOICE'
  };
}
