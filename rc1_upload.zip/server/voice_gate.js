import { AutoProcessor, AutoModel } from "@huggingface/transformers";

const MODEL_ID = process.env.DR_AI_SPEAKER_MODEL || "Xenova/wavlm-base-sv";
const THRESHOLD = Number(process.env.DR_AI_VOICE_THRESHOLD || "0.84");
const UNKNOWN_FLOOR = Number(process.env.DR_AI_VOICE_UNKNOWN_FLOOR || "0.76");
const STABLE_FRAMES = Number(process.env.DR_AI_VOICE_STABLE_FRAMES || "3");

let processorPromise;
let modelPromise;

async function loadModel() {
  if (!processorPromise) {
    processorPromise = AutoProcessor.from_pretrained(MODEL_ID);
    modelPromise = AutoModel.from_pretrained(MODEL_ID);
  }
  return { processor: await processorPromise, model: await modelPromise };
}

function cosine(a,b){
  let dot=0, na=0, nb=0;
  const n=Math.min(a.length,b.length);
  for(let i=0;i<n;i++){ dot+=a[i]*b[i]; na+=a[i]*a[i]; nb+=b[i]*b[i]; }
  return dot/(Math.sqrt(na)*Math.sqrt(nb)+1e-12);
}

function pcm16ToFloat32(buf){
  const n=Math.floor(buf.length/2), out=new Float32Array(n);
  for(let i=0;i<n;i++) out[i]=buf.readInt16LE(i*2)/32768;
  return out;
}

function resampleLinear(input, fromRate, toRate){
  if(fromRate===toRate) return input;
  const len=Math.max(1,Math.round(input.length*toRate/fromRate));
  const out=new Float32Array(len);
  const ratio=(input.length-1)/Math.max(1,len-1);
  for(let i=0;i<len;i++){
    const p=i*ratio, j=Math.floor(p), f=p-j;
    out[i]=(input[j]??0)*(1-f)+(input[j+1]??input[j]??0)*f;
  }
  return out;
}

async function embeddingFromPcm16(pcm, sampleRate=16000){
  const {processor,model}=await loadModel();
  const audio=resampleLinear(pcm16ToFloat32(pcm),sampleRate,16000);
  const inputs=await processor(audio);
  const out=await model(inputs);
  const e=out.embeddings?.data || out.logits?.data;
  if(!e) throw new Error("Speaker model returned no embedding");
  return Array.from(e);
}

let enrolled=null;
let matches=0;
let guestClusters=[];
let nextGuestId=1;
const GUEST_MATCH_THRESHOLD = Number(process.env.DR_AI_GUEST_CLUSTER_THRESHOLD || "0.78");
const MAX_GUEST_CLUSTERS = Number(process.env.DR_AI_MAX_GUEST_CLUSTERS || "6");

export async function enrollFromPcm16(pcmChunks, sampleRate=16000){
  const embeddings=[];
  for(const c of pcmChunks) embeddings.push(await embeddingFromPcm16(c,sampleRate));
  if(!embeddings.length) throw new Error("No enrollment audio");
  const dim=embeddings[0].length, centroid=new Float32Array(dim);
  for(const e of embeddings) for(let i=0;i<dim;i++) centroid[i]+=e[i]/embeddings.length;
  let norm=0; for(const v of centroid) norm+=v*v;
  norm=Math.sqrt(norm)||1; for(let i=0;i<dim;i++) centroid[i]/=norm;
  enrolled=Array.from(centroid);
  matches=0;
  guestClusters=[]; nextGuestId=1;
  return {model:MODEL_ID,dimension:dim,samples:embeddings.length,threshold:THRESHOLD,unknownFloor:UNKNOWN_FLOOR};
}

function identifyGuest(e){
  let best=-1, bestScore=-1;
  for(let i=0;i<guestClusters.length;i++){
    const s=cosine(e,guestClusters[i].centroid);
    if(s>bestScore){bestScore=s;best=i;}
  }
  if(best>=0 && bestScore>=GUEST_MATCH_THRESHOLD){
    const c=guestClusters[best];
    c.count++;
    const a=c.centroid;
    for(let i=0;i<a.length;i++) a[i]=a[i] + (e[i]-a[i])/c.count;
    return {speakerId:c.id,score:bestScore,reason:"guest cluster match"};
  }
  if(guestClusters.length<MAX_GUEST_CLUSTERS){
    const id=`GUEST_${nextGuestId++}`;
    guestClusters.push({id,centroid:e.slice(),count:1});
    return {speakerId:id,score:null,reason:"new guest cluster"};
  }
  return {speakerId:"GUEST_UNKNOWN",score:bestScore,reason:"guest cluster limit reached"};
}

export async function verifyPcm16(pcm,sampleRate=16000){
  const e=await embeddingFromPcm16(pcm,sampleRate);
  if(enrolled){
    const score=cosine(e,enrolled);
    if(score>=THRESHOLD){
      matches++;
      if(matches>=STABLE_FRAMES) return {state:"MATCH",score,speakerId:"HOST",reason:"stable host speaker match"};
      return {state:"UNKNOWN",score,speakerId:"HOST_CANDIDATE",reason:"waiting for stable host match"};
    }
    matches=0;
    if(score>=UNKNOWN_FLOOR){
      const g=identifyGuest(e);
      return {state:"UNKNOWN",score,speakerId:g.speakerId,reason:"ambiguous host vs guest; "+g.reason};
    }
    const g=identifyGuest(e);
    return {state:"NON_MATCH",score,speakerId:g.speakerId,reason:"guest speaker; "+g.reason};
  }
  const g=identifyGuest(e);
  return {state:"UNKNOWN",score:g.score,speakerId:g.speakerId,reason:"no host enrollment; "+g.reason};
}

export function resetGate(){ matches=0; guestClusters=[]; nextGuestId=1; }
export function isEnrolled(){ return !!enrolled; }
export function modelInfo(){ return {model:MODEL_ID,threshold:THRESHOLD,unknownFloor:UNKNOWN_FLOOR,stableFrames:STABLE_FRAMES,enrolled:isEnrolled()}; }
