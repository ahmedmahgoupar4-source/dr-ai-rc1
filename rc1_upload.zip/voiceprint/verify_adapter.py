"""Production adapter boundary.

Expected integration:
    PCM 16 kHz mono -> speaker embedding -> cosine similarity -> HostVoiceGate

The adapter refuses to authenticate when no real embedding model is configured.
This prevents the app from accidentally treating a weak acoustic fingerprint as
Ahmed's identity.
"""
import os

MODEL = os.getenv("DR_AI_SPEAKER_MODEL", "")

class SpeakerAdapter:
    def __init__(self):
        self.configured = bool(MODEL)

    def score(self, pcm16k_mono: bytes) -> float:
        if not self.configured:
            raise RuntimeError("No speaker-embedding model configured; voiceprint gate is UNKNOWN")
        raise NotImplementedError("Connect the selected speaker-embedding model here")
