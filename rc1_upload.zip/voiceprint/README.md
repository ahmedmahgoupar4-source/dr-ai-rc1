# Dr. Ahmed Voiceprint Adapter — V14.2

The Controller now has a **real authentication boundary**, but the package does not
ship a speaker-embedding model or claim biometric identification.

## Runtime contract
`16 kHz mono PCM → speaker embedding → cosine similarity → calibrated gate`

The gate requires stable evidence across multiple frames. Results:
- `MATCH`: open the private director/control channel.
- `UNKNOWN`: do not open the control channel.
- `NON_MATCH`: treat the speaker as public.

A weak acoustic/MFCC fingerprint is intentionally **not** used as authentication.
The selected speaker model must be installed and calibrated before `MATCH` can be
considered authoritative.
