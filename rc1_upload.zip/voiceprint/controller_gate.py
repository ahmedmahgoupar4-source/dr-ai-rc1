"""Speaker-gate contract for Dr. AI.

This module deliberately does NOT pretend that an acoustic heuristic is a biometric
identity proof. A production deployment must inject a calibrated speaker-embedding
model (e.g. ECAPA-TDNN) and return MATCH/UNKNOWN/NON_MATCH.
"""
from dataclasses import dataclass
from enum import Enum

class GateState(str, Enum):
    MATCH = "MATCH"
    UNKNOWN = "UNKNOWN"
    NON_MATCH = "NON_MATCH"

@dataclass
class GateDecision:
    state: GateState
    score: float | None = None
    reason: str = ""

class HostVoiceGate:
    def __init__(self, threshold: float = 0.72, unknown_floor: float = 0.55, stable_frames: int = 3):
        self.threshold = threshold
        self.unknown_floor = unknown_floor
        self.stable_frames = stable_frames
        self._matches = 0

    def reset(self):
        self._matches = 0

    def accept_score(self, score: float) -> GateDecision:
        if score >= self.threshold:
            self._matches += 1
            if self._matches >= self.stable_frames:
                return GateDecision(GateState.MATCH, score, "stable speaker match")
            return GateDecision(GateState.UNKNOWN, score, "waiting for stable match")
        self._matches = 0
        if score >= self.unknown_floor:
            return GateDecision(GateState.UNKNOWN, score, "ambiguous speaker")
        return GateDecision(GateState.NON_MATCH, score, "speaker mismatch")
