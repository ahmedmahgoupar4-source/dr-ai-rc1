# Dr. AI RC-1 Cloud Build
This archive contains the RC-1 Android project plus server/voiceprint source.
The GitHub Actions workflow should unzip this archive and run Gradle 8.11 against the Android project.
No API keys are included. Configure secrets separately if the server is deployed.
