package com.drai.mobile

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(AudioBridge(this), "AndroidAudio")
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
        }
        web.layoutParams = ViewGroup.LayoutParams(-1, -1)
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        try { web.removeJavascriptInterface("AndroidAudio") } catch (_: Exception) {}
        super.onDestroy()
    }
}
